<?php

class Db{
	//Tao bien $conn ket noi
	public static $conn;
	//Tao ket noi trong ham construct
	public function __construct(){
		self::$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
		self::$conn->set_charset('utf8');
	}
	// ham viet lay du lieu
	public function getData($obj){
		$arr = array();
		while($row = $obj->fetch_assoc()){
			$arr[]=$row;
		}
		return $arr;
	}
	// Viet ham lay gia tri manu
	public function getManufactures(){
		//Viet cau SQL
		$sql = "SELECT * FROM manufactures";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return $this->getData($result);
		
	}
	//Viet ham lay ra tên và giá sản phẩm
	public function product1($page, $per_page){
		//Viet cau SQL
		$first_link = ($page - 1) * $per_page;
		$sql = "SELECT * FROM products, manufactures, prototypes WHERE products.manu_ID = manufactures.manu_ID AND products.type_ID = prototypes.type_ID LIMIT $first_link, $per_page ";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return $this->getData($result);
		
	}
	public function product2($id){
		//Viet cau SQL
		$sql = "SELECT * FROM products  WHERE products.ID = $id ";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return $this->getData($result);
		
	}
	// ham viet xoa san pham
	public function xoaSP($id){
		//Viet cau SQL
		$sql = "DELETE FROM products WHERE ID = $id";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return($result);		
	}

	public function xoaHang($id){
		//Viet cau SQL
		$sql = "DELETE FROM manufactures WHERE manu_ID = $id";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return($result);		
	}
	// ham viet kiem kiem san pham
	public function timKiemSP($key, $page, $per_page){
		$first_link = ($page - 1) * $per_page;
		//Viet cau SQL
		$sql = "SELECT * FROM products, manufactures, prototypes WHERE products.manu_ID = manufactures.manu_ID AND products.type_ID = prototypes.type_ID AND name LIKE '%$key%' LIMIT $first_link, $per_page" ;
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return $this->getData($result);		
	}
	
	// ham phan trang
	public function paginate($url, $total, $page, $per_page){
		$total_links = ceil($total/$per_page);
		$link = "";
		for($j = 1; $j <= $total_links; $j++){
			$link = $link."<li><a href='$url?page=$j'>$j</a></li>";
		}
		return $link;
	}
	// ham phan trang ben tim kiem
	public function paginate2($key, $url, $total, $page, $per_page){
		$total_links = ceil($total/$per_page);
		$link = "";
		for($j = 1; $j <= $total_links; $j++){
			$link = $link."<li><a href='$url?key=".$key."&page=$j'>$j</a></li>";
		}
		return $link;
	}	
	// ham dem so luong san pham	
	public function demSLSP(){
		$sql = "SELECT * FROM products";

		$result = self::$conn->query($sql);
		return $result->num_rows;
	}
	// 
	public function timKiemSLSP($key, $page, $per_page){
		$first_link = ($page - 1) * $per_page;
		//Viet cau SQL
		$sql = "SELECT * FROM products, manufactures, prototypes WHERE products.manu_ID = manufactures.manu_ID AND products.type_ID = prototypes.type_ID AND name LIKE '%$key%' LIMIT $first_link, $per_page";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return $this->getData($result);
	}
	// ham dem so luong san pham sau khi tim kiem
	public function demSLSPTK($key){
		$sql = "SELECT * FROM products, manufactures, prototypes WHERE products.manu_ID = manufactures.manu_ID AND products.type_ID = prototypes.type_ID AND name LIKE '%$key%'";
		$result = self::$conn->query($sql);
		return $result->num_rows;
	}
	// ham them san pham
	public function addProduct($manu_name, $type_name, $name, $description, $price, $image)
	{
		$sql = "INSERT INTO products(name, description, price, image, type_ID, manu_ID) VALUES ('$name', '$description', '$price', '$image', $type_name, $manu_name)";
		$result = self::$conn->query($sql);
		return $result;
	}
	public function editproduct($manu_id, $type_id, $name, $description, $price, $image, $id)
	{
		//viet sql
		if($image == NULL)
		{
			$sql = "UPDATE products SET manu_ID = '$manu_id', type_ID = '$type_id', description = '$description', name = '$name', price = '$price' WHERE ID = $id";
		}
		else
		{
			$sql = "UPDATE products SET manu_ID = '$manu_id', type_ID = '$type_id', description = '$description', name = '$name', price = '$price', image = '$image' WHERE ID = $id";
		}
		
		//thuc thi va tra ve?
		$result = self::$conn->query($sql);
		return $result;
	}
	
	// ham ket thuc
	public function __destruct(){
		self::$conn->close();
	}
}