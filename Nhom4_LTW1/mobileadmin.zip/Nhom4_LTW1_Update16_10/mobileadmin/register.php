<?php 
  require "users.php";
  session_start();
    if(isset($_SESSION['user'])){
        header('location: index.php');
    }
  $users = new users();
  $error = "";
  if(isset($_POST['username'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    if($password == $password2){
        $users->addUser($username, $password);
      
      header('location:login.php');
    }
    else{
      $error = "Mat khau khong khop";
    }
  }

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <title> Đăng Kí </title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Meta tag Keywords -->
<!-- css files -->
<link rel="stylesheet" href="login/css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="login/css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
<!-- //css files -->
<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800&amp;subset=latin-ext" rel="stylesheet">
<!-- //online-fonts -->
</head>
<body>
<!-- main -->
<div class="center-container">
    <!--header-->
    <div class="header-w3l">
        <h1>Bạn đang ở trang đăng kí</h1>
    </div>
    <!--//header-->
    <div class="main-content-agile">
        <div class="sub-main-w3">   
            <div class="wthree-pro">
                <h2>REGISTER</h2>
            </div>
            <form action="register.php" method="post">
                <div class="pom-agile">
                    <input placeholder="Tên đăng nhập...." name="username" class="form-control login-form" type = "text" required="">
                    <span class="icon1"><i class="fa fa-user" aria-hidden="true"></i></span>
                </div>
                <div class="pom-agile">
                    <input  placeholder="Mật khẩu...." name="password" class="form-control login-form" type="password" required="">
                    
                    <span class="error login-form"><?php echo $error ?></span>
                    <span class="icon2"><i class="fa fa-unlock" aria-hidden="true"></i></span>
                </div>
                 <div class="pom-agile">
                <input  placeholder="Nhập lại mật khẩu...." name="password2" class="form-control login-form" type="password" required="">
                
                 </div>
                <div class="sub-w3l">
                    <h6><a href="index.php">Về trang chủ</a></h6>
                    <div class="right-w3l">
                        <input type="submit" value="Register">
                    </div>
                </div>
               
            </form>
        </div>
    </div>
    
</div>
</body>
</html>