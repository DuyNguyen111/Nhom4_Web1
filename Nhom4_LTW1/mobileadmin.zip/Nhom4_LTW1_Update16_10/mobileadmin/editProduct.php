<?php
require "db.php";
require "config.php";
$id = $_POST['id'];
$name = $_POST['name'];
$type_name = $_POST['type_id'];
$manu_name = $_POST['manu_id'];
$price = $_POST['price'];
$description = $_POST['description'];


$product = new Db();
if(isset($_FILES['fileUpload']))
{
	$image = $_FILES['fileUpload']['name'];
	$target_dir = "./public/image/";
	$target_img = $target_dir . basename( $_FILES['fileUpload']['name']);
	move_uploaded_file($_FILES['fileUpload']["tmp_name"], $target_img);
}
else
{
	$image = NULL;
}	
	$product->editproduct($manu_name, $type_name, $name, $description, $price, $image, $id);
	header('location:index.php');

?>